// ==UserScript==
// @name         RSS+ : Show Site All RSS
// @name:zh      RSS+ : 显示当前网站所有的 RSS
// @name:zh-CN   RSS+ : 显示当前网站所有的 RSS
// @name:zh-TW   RSS+ : 顯示當前網站所有的 RSS
// @description         Show Site All RSS.
// @description:zh      显示当前网站所有的 RSS
// @description:zh-CN   显示当前网站所有的 RSS
// @description:zh-TW   顯示當前網站所有的 RSS
// @date          2018.09.16
// @modified	  2018.10.23
// @version       0.4

// @icon         http://www.inoreader.com/favicon.ico
// @author       Wizos
// @namespace    https://blog.wizos.me
// @supportURL   wizos@qq.com
// @contributionURL   https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=wizos@qq.com&item_name=Greasy+Fork+donation
// @contributionAmount 2
// @include *
// @match        http://*/*
// @match        https://*/*
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// @grant        GM_notification
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        unsafeWindow
// @noframes
// @run-at     document-end
// ==/UserScript==

// 2018.10.29_0.4 1.在无法链接服务器时也能展示本地的RSS；2.开启 Content-Security-Policy 的网站，直接展示本地的RSS；增加发现RSS后，进行h5通知
// 2018.10.23_0.4 1.增加识别为 wordpress 站点时，尝试使用/feed后缀；2.增加多语言支持
// 2018-10-16_0.3 1.改为iframe方式显示，兼容性更好；2.改为post方式传递页面地址；
// 2018-10-14_0.2 第一个 RSS+ 成型；
// 2018.09.16_0.1 在 RSS+Atom Feed Subscribe Button Generator 脚本基础上增加连接后端获取feed的方式；
if(location.href.match(/api\.wizos\.me/i)){
    return;
}

var feeds = [];
var feedsMap = {};

var zhcn = {
    "copied":"已复制",
    "copy" : "复制",
    "copy_succeeded" : "复制成功",
    "follow" : "订阅",
    "found":"发现 ",
    "feed": " 个订阅源",
    "click_the_number_to_view":"点击右下角的数字查看",
    "close": "关闭"
};
var zh = zhcn;
var zhtw = {
    "copied":"已複製",
    "copy" : "複製",
    "copy_succeeded" : "複製成功",
    "follow" : "訂閱",
    "found":"發現 ",
    "feed": " 個訂閱源",
    "click_the_number_to_view":"點擊右下角的數位查看",
    "close": "關閉"
};
var en = {
    "copied":"copied",
    "copy" : "copy",
    "copy_succeeded" : "copy succeeded",
    "follow" : "follow",
    "found":"found ",
    "feed": " feed",
    "click_the_number_to_view":"click on the number in the lower right corner to view it",
    "close": "close"
};

var languages = {};
languages.zhcn = zhcn;
languages.zhtw = zhtw;
languages.zh = zh;
languages.en = en;
var language = navigator.language.replace('-',"").toLowerCase();
var lang = languages[language];
if( !lang ){
  lang = languages.en;
}

setTimeout(function(){
    if(location.href.match(/github\.com/i)){
        show();
    }else{
        showWithCloudFeeds( location.href );
    }
},0);


function showWithCloudFeeds(url) {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        //console.log("当前状态A：" + ajax.readyState + "，" + ajax.status );
        if ( ajax.readyState != 4 ) {
            return;
        }
        if( ajax.status == 200 ){
            var obj = JSON.parse(ajax.responseText);
            show(obj.feeds);
        }else{
            show();
        }
    };
    ajax.open("POST", "https://api.wizos.me/find.php", true);
    var data = new FormData();
    data.append("url",url);
    ajax.send( data );
}

function show(cloudFeeds) {
    getKnowFeeds();
    getUnknownFeeds();
    if (cloudFeeds != null) {
      console.log("云端有feeds");
      console.log(cloudFeeds);
      cloudFeeds.forEach(element => {
          addRSS(element.title, element.link, element.type);
      });
    }
    render(feeds);
}

function addRSS(title, link, type) {
  // console.log("添加新的RSS：" + title + "，" + link);
  var feed = {};
  feed.title = title;
  feed.link = link.toLowerCase().replace(/(\/$)/g,"");
    // 放重复
    if (!feedsMap[feed.link]) {
      //如果能查找到，证明数组元素重复了
      feedsMap[feed.link] = 1;
      feeds.push(feed);
    }
}

// 获取在<head>的<link>元素中，已经声明为RSS的链接
function getKnowFeeds() {
  var linkElems = document.getElementsByTagName("link");
  var link;
  for (var i = 0, l = linkElems.length; i < l; i++) {
    link = linkElems[i];
    if (!link) continue;
    var linkhref = link.href;
    var linktype = link.type;
    var linktitle = document.title;
    if (link.title) {
      linktitle = link.title;
    }
    if (linktype && linktype.match(/.*\/(rss|atom)\+xml?$/i)) {
      addRSS(linktitle, linkhref);
    } else if (linktype && linktype.match(/^text\/xml$/i)) {
      addRSS(linktitle, linkhref);
    }
  }
}

function getUnknownFeeds() {
  var link;
  var headlinks = document.querySelectorAll("head > link");
  for (var i = 0, len = headlinks.length; i < len; i++) {
    link = headlinks[i];
    if(link.href.match(/wp-content/)){
      checkFeed( document.location.protocol + '//' + document.domain );
      break;
    }
  }

  if (!document.links) {
    document.links = document.getElementsByTagName("a");
  }
  var links = document.links;
  for (var a = 0, len = links.length; a < len; a++) {
    link = links[a];
    var linkhref = link.href;
    var linktitle = document.title;
    if (link.title) {
      linktitle = link.title;
    } else if (link.innerText) {
      linktitle = link.innerText;
    }
    // console.log("检查RSS：" + linkhref + "  , " + link.title);
    if (
      linkhref.match(/^rss:/) ||
      linkhref.match(
        /^(https|http|ftp|feed).*([\.\/]rss([\.\/]xml|\.aspx|\.jsp|\/)?$|\/node\/feed$|\/rss\/[a-z0-9]+$|[?&;](rss|xml|rdf)=|[?&;]feed=rss[0-9.]*$|[?&;]action=rss_rc$|feeds\.feedburner\.com\/[\w\W]+$)/i
      )
    ) {
      addRSS(linktitle, linkhref);
    } else if (
      linkhref.match(
        /^(https|http|ftp|feed).*\/atom(\.xml|\.aspx|\.jsp|\/)?$|[?&;]feed=atom[0-9.]*$/i
      )
    ) {
      addRSS(linktitle, linkhref);
    } else if (
      linkhref.match(
        /^(https|http|ftp|feed).*(\/feeds?\/[^.\/]*\.xml$|.*\/index\.xml$|feed\/msgs\.xml(\?num=\d+)?$)/i
      )
    ) {
      addRSS(linktitle, linkhref);
    } else if (linkhref.match(/^(https|http|ftp|feed).*\.rdf$/i)) {
      addRSS(linktitle, linkhref);
    } else if (linkhref.match(/^feed:\/\//i)) {
      addRSS(linktitle, linkhref);
    }
  }
}
var wp_feed_suffix = ['/?feed=rss2','/?feed=rss','/feed'];
function checkFeed(href) {
  var flag = wp_feed_suffix.pop();
  //console.log("弹出：" + flag );
  if( !flag){
      return;
  }
  var ajax = new XMLHttpRequest();
  ajax.onreadystatechange = function() {
    if( ajax.readyState == 4 ) {
      if( ajax.status == 200 ){
        addRSS(document.title, href + flag);
      }else{
        checkFeed(href);
      }
    }
  };
  ajax.open("HEAD", href + flag, false);
  ajax.send();
}

function render(feeds) {
  if (!feeds || feeds.length <= 0) {
    console.log("该页没有发现feed");
    return;
  }
  var rss_plus_html = "";
  var element, tips, desc;
  for (var i = 0; i < feeds.length; i++) {
    element = feeds[i];
    tips = "";
    desc = "";
    // console.log("feed信息：" + element.title + element.link);

    if (element.follows) {
      tips = " - " + element.follows + "人订阅";
    }
    if (element.update) {
      tips += " - " + element.update + "更新";
    }
    if (element.desc) {
      desc = ' title="' + element.desc + '"';
    }
    rss_plus_html +=
      '<tr><td class=""><div class="rp-table-cell"><div class="feed-title"' +
      desc +
      ">" +
      element.title +
      '</div><div class="feed-tips"><a href="' + element.link + '" target="_blank">' +
      element.link + '</a>' +
      tips +
      '</div></div></td><td class="rp-table-column-center"><div class="rp-table-cell" sytle="display:inline">';
    rss_plus_html +=
      '<button type="button" index="' +
      i +
      '" class="rp-btn rp-btn-primary rp-btn-small rp-copy-feed-link" data-clipboard-action="copy" data-clipboard-target=".feed-title"><i class="rp-icon icon-copy"></i><span>' + lang.copy +'</span></button>';
    rss_plus_html +=
      '<button type="button" index="' +
      i +
      '" class="rp-btn rp-btn-primary rp-btn-small rp-follow-feed-link"><i class="rp-icon icon-subs"></i><span>' + lang.follow +'</span></button></div></td></tr>';
  }

  var rss_count_badge_html =
    '<div id="rp-feed-badge" class="rp-card rp-card-bordered"><span class="rp-badge-count" place="count">' +
    feeds.length +
    "</span></div>";

  var rss_feed_list_html =
    '<div id="rp-feed-list" class="rp-card rp-card-bordered"><div id="rp-card-head" class="rp-card-head"><div class="card-title"><i class="rp-icon icon-star"></i>' + lang.found +'<span class="rp-mark-count" place="count">' +
    feeds.length +
    '</span>' + lang.feed +' -【RSS+】</div></div><div class="rp-card-extra"><button type="button" id="rp-close-btn" class="rp-btn rp-btn-dashed" title="' + lang.close +'"> <span><i class="rp-icon icon-close"></i></span></button></div>';

  rss_feed_list_html +=
    '<div id="rp-card-body"><div class="rp-table"><table cellspacing="0" cellpadding="0" border="0"><colgroup><col width="70%"><col width="30%"></colgroup><tbody class="rp-table-tbody">' +
    rss_plus_html +
    "</tbody></table></div></div></div></div>";

  var styleEl = document.createElement("style");
  styleEl.innerHTML = styleHtml;

  // 安装 RSS Plus Box 和 RSS Plus Frame
  var rssPlusDiv = document.createElement("div");
  rssPlusDiv.setAttribute("id", "rss-plus");

  var rssPlusWrapDiv = document.createElement("div");
  rssPlusWrapDiv.setAttribute("id", "rss-plus-wrap");
  rssPlusWrapDiv.innerHTML = '<iframe name="rpJSFrame" src="about:blank" style="width:100%;height:100%;border:0px;display: block!important;" allowTransparency="true"></iframe>';

  var rssPlusWrapStyle = document.createElement("style");
  rssPlusWrapStyle.innerHTML = '#rss-plus-wrap{position:fixed;width:370px;bottom:10px;right:20px;z-index:999;height:56px}';

  rssPlusDiv.insertBefore(rssPlusWrapDiv,rssPlusDiv.firstChild);
  rssPlusDiv.insertBefore(rssPlusWrapStyle, rssPlusWrapDiv);

  //var head = document.getElementsByTagName("head");
  //if (head && head[0]) head = head[0];
  var body = document.getElementsByTagName("body");
  if (body && body[0]) body = body[0];
  insertAfter(rssPlusDiv, body.lastChild);
  // body.insertBefore(rssPlusBoxDiv, body.firstChild);

  var rssPlusBoxDiv = document.createElement("div");
  rssPlusBoxDiv.setAttribute("id", "RSSPlusBox");
  rssPlusBoxDiv.innerHTML = rss_count_badge_html + rss_feed_list_html;

  var frameBody = rpJSFrame.window.document.getElementsByTagName("body");
  if (frameBody && frameBody[0]) frameBody = frameBody[0];
  frameBody.insertBefore(rssPlusBoxDiv, frameBody.firstChild);
  frameBody.insertBefore(styleEl, frameBody.firstChild);

  var rpFeedBadgeDiv = rpJSFrame.window.document.getElementById("rp-feed-badge");
  var rpCloseDiv = rpJSFrame.window.document.getElementById("rp-close-btn");
  addEventHandler(rpCloseDiv, "click", function() {
    rpJSFrame.window.document.getElementById("rp-feed-list").style.display = "none";
    rpJSFrame.window.document.getElementById("rp-feed-badge").style.display = "block";
    rssPlusWrapDiv.style.width = rpJSFrame.window.document.getElementById("rp-feed-badge").offsetWidth  + "px";
    rssPlusWrapDiv.style.height = rpJSFrame.window.document.getElementById("rp-feed-badge").offsetHeight  + "px";

  });
  addEventHandler(rpFeedBadgeDiv, "click", function() {
    rpJSFrame.window.document.getElementById("rp-feed-list").style.display = "block";
    rpJSFrame.window.document.getElementById("rp-feed-badge").style.display = "none";
    rssPlusWrapDiv.style.width = rpJSFrame.window.document.getElementById("RSSPlusBox").offsetWidth + "px";
    rssPlusWrapDiv.style.height = rpJSFrame.window.document.getElementById("RSSPlusBox").offsetHeight + "px";
  });

  var copyFeedLinkButtons = rpJSFrame.window.document.getElementsByClassName("rp-copy-feed-link");
  var followFeedLinkButtons = rpJSFrame.window.document.getElementsByClassName("rp-follow-feed-link");
  for (i = 0; i < copyFeedLinkButtons.length; i++) {
    addEventHandler(copyFeedLinkButtons[i], "click", function() {
      copyFeedLink(this.getAttribute("index"));
    });
  }
  for (i = 0; i < followFeedLinkButtons.length; i++) {
    addEventHandler(followFeedLinkButtons[i], "click", function() {
      followFeedLink(this.getAttribute("index"));
    });
  }

  GM_notification({
    title: lang.found + " " + feeds.length + " " + lang.feed,
    text: lang.click_the_number_to_view,
    timeout: 3000
  });
}



function copyFeedLink(index) {
  GM_setClipboard(feeds[index].link);
  GM_notification({
    text:  lang.copied + ": " + feeds[index].link,
    title: lang.copy_succeeded,
    timeout: 2000
  });
}

function followFeedLink(index) {
  // [feedly]https://feedly.com/i/subscription/feed%2Fhttp%3A%2F%2Ffeeds.howtogeek.com%2FHowToGeek
  // [inoreader]http://www.inoreader.com/?add_feed=https%3A%2F%2Fwww.howtogeek.com%2Ffeed%2F
  // [NewsBlur]http://www.newsblur.com/?url=https%3A%2F%2Ffeeds.howtogeek.com%2FHowToGeek
  // [theoldreader]https://theoldreader.com/feeds/subscribe?url=https://api.izgq.net/weibo/rss/1197161814
  window.open("https://www.inoreader.com/?add_feed=" + feeds[index].link, "_blank");
}

function addEventHandler(target, eventName, eventHandler, scope) {
  var f = scope? function() {
        eventHandler.apply(scope, arguments);
      }
    : eventHandler;
  if (target.addEventListener) {
    target.addEventListener(eventName, f, true);
  } else if (target.attachEvent) {
    target.attachEvent("on" + eventName, f);
  }
  return f;
}

function setupJsIframe(){
  var jsIframeDiv = document.createElement("div");
  jsIframeDiv.setAttribute("id", "RSSPlusFrame");
  jsIframeDiv.innerHTML = '<iframe name="rpJSFrame" src="about:blank" style="width:100%;height:100%;border:0px;display: block!important;" allowTransparency="true"></iframe>';
  var body = document.getElementsByTagName("body");
  if (body && body[0]) body = body[0];
  insertAfter(jsIframeDiv, body.lastChild);
}

// source: https://blog.csdn.net/liuyingshuai_blog/article/details/54580633?utm_source=copy
function insertAfter(newElement,targetElement){
  var parent=targetElement.parentNode;
  if(parent.lastChild==targetElement){
    parent.appendChild(newElement);
  }else{
    parent.insertBefore(newElement,targetElement.nextSibling);
  }
}
var styleHtml =
  '@font-face {font-family: "RSSPlus";src: url("iconfont.eot?t=1539525813084");src: url("iconfont.eot?t=1539525813084#iefix") format("embedded-opentype"),url("data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAeQAAsAAAAACswAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAADMAAABCsP6z7U9TLzIAAAE8AAAARAAAAFY8ekqWY21hcAAAAYAAAACIAAAB9E+T711nbHlmAAACCAAAA1AAAAQErsKsIWhlYWQAAAVYAAAALwAAADYS9h9jaGhlYQAABYgAAAAgAAAAJAfjA4VobXR4AAAFqAAAAA4AAAAgIAAAAGxvY2EAAAW4AAAAEgAAABIE2gOgbWF4cAAABcwAAAAfAAAAIAEWAExuYW1lAAAF7AAAAVAAAAJh2T26s3Bvc3QAAAc8AAAAUQAAAGelvVyNeJxjYGRgYOBikGPQYWB0cfMJYeBgYGGAAJAMY05meiJQDMoDyrGAaQ4gZoOIAgCKIwNPAHicY2BkYWCcwMDKwMHUyXSGgYGhH0IzvmYwYuRgYGBiYGVmwAoC0lxTGByeMbxYwtzwv4EhhrmBoQUozAiSAwDpnQyNeJztkcsJw0AMREdZf8Dk4KsL8C21GNxATinFJ59ShGsb3IU9kgImkBIi8RY0q13BCEANoIiHqAB7w+CxSrXQC7rQKzxV90r1Exw4cuLMZd+O45fyFRYvr/RpLRrNv+lOP1qDf9zjfH2q1l1NfDccktDHRA6CU+K75JzIVXBJfI/7lqCcrFEpD3icVVJdaBxVFD5n7vzsNmF2BudnN2ZnOzPJTLsh253Mzkw2NVmzIt2tVCRiXEWpWEEKrSCBouBKLO5j8aH4IvjbNrHiQ0mlrSjiNg99ME8RfRH0oSBU4kvehHr1zriIzsO555zvu/d8c84BHuCvG+Rr0gYNLPAhAEBPNC00DdE0YuaERuzHHtZwCRMLNdFMvTlj5GQpDu7tIqpyrqlOfZ54vSgNf6RHyy56pbLrbqfOnOcNLSdNOA55GH/4tf1K/dBFywhyB/Lc7r3fdimfkvBf878A2McxrevkTbIGMzDPdLqqVkAnmK6hI0qCrzI1NhOuh1ENfVtGSU3iqSQ0+AqSMAojN3J1Vw918lpEOEL3iFpUeHpXwMDCn60AI+xG1Ii6mGtgaXKsiGPHchdzg0E0GGCB/sQRcokTBO5SjvDlgOOC8hNPRV2OO5bcv0BKn6jye1MEP0vZ0QAI0/oNEckilMGFwwCCG3l+YphMW9RIolA3TMnzdYvTNVEiMuqa+cBcHDV8rtS5k6xVzlxYvdvZnDkzefx0d+H1tU6tdbYTPnKufUq9NvFq7nv7pUe/mDxxQn/HXJG+sg4+v/TMuQPcWZydfUymVxeOPG6wfqUa3iW75DSYMAXTTIPoHEEZXdaebHImK20amsRyEotYjiEB+bLUnvh09uVka08Q9raYrVc/LBZpsX+F56/0+xuEbPSfLBavlh7kf9+6npKud9+OP2K3SIvfGBH6GzyMNHxLhmQZClCBFpuahbqqia7teJHaiJPpbFCsus3KqzVEm2lQR4vlyinZCG3WmXTpdBnJc+OKMk6XUou36dLMPOL8DN7OTrpPX1zuIfaWFU1TnHrdwQ+cOmoVDXvcH1gYp4vZve3xAnawWaWL1SayE7erzftvYa+N77ef5jJ+3aGnnCBwCppWaPey3fuY/EJOwhjo7C9EkAwwY0g8IL6U+C2soMTBDt0XBJR3dlAWBLp/6PLlyuDWysqtATnJwp1/4MJ3DP7z8OrqzfMTm5sT59M+IXv/DZ4n63AQII9eI4nnzDwyw+aTZ02TOc/Po+j4DMIX6NC23WddbGGLHbZNh9jSFaX6UNOgQzrMcrj+HzCjp5CxcLSqKDq2Rk8A/A1Nx9+eeJxjYGRgYABidpm47fH8Nl8ZuFkYQOD6y9ytCPp/DQsLcwOQy8HABBIFACQ/Cr0AeJxjYGRgYG7438AQw8LAwPD/DwsLA1AEBXAAAHHwBHB4nGNhYGBgwYMBAmAAIQAAAAAAAABWAKwA7gEwAZQBxAICAAB4nGNgZGBg4GBwYGBhAAEmIOYCQgaG/2A+AwAPvgFjAHicZZG9asMwFIWPmz/qQIeWduogKHRIwfkZQ7dAsoYEsnVIHDlxsC0jK4GMfZ4+QZ+gT9C1S5+iWw/2DZTUQlffPbo6vpYBXOMLHqrnlrNiDy1mFV+Q74Vr5AfhOrkj3EAbfeEm9WdhH08YCbdxg4wOXv2SWQevwh6u8CZ8QX4XrpE/hOvkT+EG7vAt3KT+I+xj4bWE23j0XvyR1Uun12p1VHFosshkzp/N59NkX8z0Zp8s7SmrloW2RWwy1Q96okx0pu3JozhsBs5FKrImVWOa6SQxKrdmp0MXbJ3Lh91uJHoQmpQtjWChsYRjXENhhSNjjBCGlxGV0bFuhjnHFAn2KJhpbEgJT9p/e3+zBSst17h0UvwJAXpnNRPWZGXdeR8FDnzPgKpjL4rT0icljaUzTY+ErJCXezsqIfUA2/JUjiG6HNFZfVB+YfoL46lpQXicbclBDoAgDAXRfkWK3oYjaQRsjLAgTcTTS+LWt5yhgT4L/XMYMMJgggXDYSaOaz5VPO+SU9PAV5Cma+ZatGrxU9TnEHP3a1PvmxC9+nQSQQAAAA==") format("woff"),url("iconfont.ttf?t=1539525813084") format("truetype"),url("iconfont.svg?t=1539525813084#RSSPlus") format("svg");}.rp-icon{display:inline-block;font-family:RSSPlus !important;speak:none;font-style:normal;font-weight:400;font-variant:normal;text-transform:none;text-rendering:auto;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.icon-subs:before { content: "\\e651"; }.icon-dollar:before { content: "\\e8a4"; }.icon-feedback:before { content: "\\e684"; }.icon-search:before { content: "\\e600"; }.icon-copy:before { content: "\\e64e"; }.icon-star:before { content: "\\e625"; }.icon-close:before { content: "\\e619"; } body {margin: 0px;}#RSSPlusBox { position:fixed;z-index:99999;bottom:0px; right:0px; width:600px;max-height:460px;}div.feed-title { font-weight: bold;font-size:0.8rem; cursor: pointer;}div.feed-tips,div.feed-tips a { font-size: 0.75rem; color: rgb(158, 158, 158);}.card-title {}.rp-card-extra { position:absolute;right:16px;top:1px;}.rp-table-body { max-height: 400px; height: auto; overflow-x: hidden;}.table-footer { position: fixed; bottom: 0 ; padding-left: 10px; width: 100%; background-color: #fff;}.table-footer a { color: #ed3f14;}.support-box { height: 28px; line-height: 28px;}#rp-feed-list{display:none;z-index:23333;box-shadow: 1px 1px 2px 2px #4242426b;} #rp-feed-badge{width: 28px; height: 28px; line-height: 28px; border-radius: 14px; float: right;cursor: pointer;z-index:23333;}#rp-feed-badge:hover{border-color:#e9eaec}.badge{ top:-17px; left: -6%; width: 26px; height: 26px; line-height: 26px; border-radius: 13px;}.rp-card:hover{-webkit-box-shadow:0 1px 6px rgba(0,0,0,.2);box-shadow:0 1px 6px rgba(0,0,0,.2);border-color:#eee}.rp-card{background:#fff;border-radius:4px;font-size:14px;position:relative;-webkit-transition:all .2s ease-in-out;transition:all .2s ease-in-out}.rp-card-bordered:hover{border-color:#e9eaec}.rp-card-bordered{border:1px solid #dddee1;border-color:#e9eaec}.rp-mark-count{font-weight:bold;color: #ed3f14;}.rp-badge-count{position:relative;display:inline-block;width: 26px;height: 26px;line-height: 26px;border-radius: 15px;min-width: 20px;background:#4b5979;border: 1px solid transparent;color: #fff;text-align: center;font-size: 12px;white-space: nowrap;-webkit-transform-origin: -10% center;-ms-transform-origin: -10% center;transform-origin: -10% center;z-index: 10;-webkit-box-shadow: 0 0 0 1px #fff;box-shadow: 0 0 0 1px #fff;}.rp-badge-count a,.rp-badge-count a:hover{color:#fff}.rp-card-head{border-bottom:1px solid #e9eaec;padding:10px 16px;line-height:1}.rp-tooltip{display:inline-block}.rp-tooltip-rel{display:inline-block;position:relative}.rp-btn{display:inline-block;margin-bottom:0;font-weight:400;text-align:center;vertical-align:middle;-ms-touch-action:manipulation;touch-action:manipulation;cursor:pointer;background-image:none;border:1px solid transparent;white-space:nowrap;line-height:1.5;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;padding:6px 15px;font-size:12px;border-radius:4px;-webkit-transition:color .2s linear,background-color .2s linear,border .2s linear,-webkit-box-shadow .2s linear;transition:color .2s linear,background-color .2s linear,border .2s linear,-webkit-box-shadow .2s linear;transition:color .2s linear,background-color .2s linear,border .2s linear,box-shadow .2s linear;transition:color .2s linear,background-color .2s linear,border .2s linear,box-shadow .2s linear,-webkit-box-shadow .2s linear;color:#495060;background-color:#f7f7f7;border-color:#dddee1}.rp-btn>.rp-icon{line-height:1}.rp-btn,.rp-btn:active,.rp-btn:focus{outline:0}.rp-btn:not([disabled]):hover{text-decoration:none}.rp-btn:not([disabled]):active{outline:0}.rp-btn.disabled,.rp-btn[disabled]{cursor:not-allowed}.rp-btn.disabled>*,.rp-btn[disabled]>*{pointer-events:none}.rp-btn>a:only-child{color:currentColor}.rp-btn>a:only-child:after{content:"";position:absolute;top:0;left:0;bottom:0;right:0;background:0 0}.rp-btn:hover{color:#6d7380;background-color:#f9f9f9;border-color:#e4e5e7}.rp-btn:hover>a:only-child{color:currentColor}.rp-btn:hover>a:only-child:after{content:"";position:absolute;top:0;left:0;bottom:0;right:0;background:0 0}.rp-btn.active,.rp-btn:active{color:#454c5b;background-color:#ebebeb;border-color:#ebebeb}.rp-btn.active>a:only-child,.rp-btn:active>a:only-child{color:currentColor}.rp-btn.active>a:only-child:after,.rp-btn:active>a:only-child:after{content:"";position:absolute;top:0;left:0;bottom:0;right:0;background:0 0}.rp-btn.disabled,.rp-btn.disabled.active,.rp-btn.disabled:active,.rp-btn.disabled:focus,.rp-btn.disabled:hover,.rp-btn[disabled],.rp-btn[disabled].active,.rp-btn[disabled]:active,.rp-btn[disabled]:focus,.rp-btn[disabled]:hover,fieldset[disabled] .rp-btn,fieldset[disabled] .rp-btn.active,fieldset[disabled] .rp-btn:active,fieldset[disabled] .rp-btn:focus,fieldset[disabled] .rp-btn:hover{color:#bbbec4;background-color:#f7f7f7;border-color:#dddee1}.rp-btn.disabled.active>a:only-child,.rp-btn.disabled:active>a:only-child,.rp-btn.disabled:focus>a:only-child,.rp-btn.disabled:hover>a:only-child,.rp-btn.disabled>a:only-child,.rp-btn[disabled].active>a:only-child,.rp-btn[disabled]:active>a:only-child,.rp-btn[disabled]:focus>a:only-child,.rp-btn[disabled]:hover>a:only-child,.rp-btn[disabled]>a:only-child,fieldset[disabled] .rp-btn.active>a:only-child,fieldset[disabled] .rp-btn:active>a:only-child,fieldset[disabled] .rp-btn:focus>a:only-child,fieldset[disabled] .rp-btn:hover>a:only-child,fieldset[disabled] .rp-btn>a:only-child{color:currentColor}.rp-btn.disabled.active>a:only-child:after,.rp-btn.disabled:active>a:only-child:after,.rp-btn.disabled:focus>a:only-child:after,.rp-btn.disabled:hover>a:only-child:after,.rp-btn.disabled>a:only-child:after,.rp-btn[disabled].active>a:only-child:after,.rp-btn[disabled]:active>a:only-child:after,.rp-btn[disabled]:focus>a:only-child:after,.rp-btn[disabled]:hover>a:only-child:after,.rp-btn[disabled]>a:only-child:after,fieldset[disabled] .rp-btn.active>a:only-child:after,fieldset[disabled] .rp-btn:active>a:only-child:after,fieldset[disabled] .rp-btn:focus>a:only-child:after,fieldset[disabled] .rp-btn:hover>a:only-child:after,fieldset[disabled] .rp-btn>a:only-child:after{content:"";position:absolute;top:0;left:0;bottom:0;right:0;background:0 0}.rp-btn:hover{color:#57a3f3;background-color:#fff;border-color:#57a3f3}.rp-btn:hover>a:only-child{color:currentColor}.rp-btn:hover>a:only-child:after{content:"";position:absolute;top:0;left:0;bottom:0;right:0;background:0 0}.rp-btn.active,.rp-btn:active{color:#2b85e4;background-color:#fff;border-color:#2b85e4}.rp-btn.active>a:only-child,.rp-btn:active>a:only-child{color:currentColor}.rp-btn.active>a:only-child:after,.rp-btn:active>a:only-child:after{content:"";position:absolute;top:0;left:0;bottom:0;right:0;background:0 0}.rp-btn:focus{-webkit-box-shadow:0 0 0 2px rgba(45,140,240,.2);box-shadow:0 0 0 2px rgba(45,140,240,.2)}.rp-btn-long{width:100%}.rp-btn>.rp-icon+span,.rp-btn>span+.rp-icon{margin-left:4px}.rp-table{width:inherit;max-height:280px;max-width:100%;overflow:auto;color:#495060;font-size:12px;background-color:#fff;-webkit-box-sizing:border-box;box-sizing:border-box}.rp-table:before{content:"";width:100%;height:1px;position:absolute;left:0;bottom:0;background-color:#dddee1;z-index:1}.rp-table:after{content:"";width:1px;height:100%;position:absolute;top:0;right:0;background-color:#dddee1;z-index:3}.rp-table-body{overflow:auto}.rp-table td,.rp-table th{min-width:0;height:48px;-webkit-box-sizing:border-box;box-sizing:border-box;text-align:left;text-overflow:ellipsis;vertical-align:middle;border-bottom:1px solid #e9eaec}.rp-table th{height:40px;white-space:nowrap;overflow:hidden;background-color:#f8f8f9}.rp-table td{background-color:#fff;-webkit-transition:background-color .2s ease-in-out;transition:background-color .2s ease-in-out}//.rp-table-cell span{display:none}.rp-table-cell{display:inline-block;word-wrap:normal;vertical-align:middle}.rp-table-cell{padding-top:5px; padding-bottom:5px; padding-left:18px;padding-right:18px;overflow:hidden;text-overflow:ellipsis;white-space:normal;word-break:break-all;-webkit-box-sizing:border-box;box-sizing:border-box}td.rp-table-column-center,th.rp-table-column-center{text-align:center}td.rp-table-column-right,th.rp-table-column-right{text-align:right}.rp-table table{table-layout:fixed;width: 100%;}.rp-btn-primary{color:#fff;background-color:#2d8cf0;border-color:#2d8cf0;margin:5px;}.rp-btn-primary>a:only-child{color:currentColor}.rp-btn-primary>a:only-child:after{content:"";position:absolute;top:0;left:0;bottom:0;right:0;background:0 0}.rp-btn-primary:hover{color:#fff;background-color:#57a3f3;border-color:#57a3f3}.rp-btn-primary:hover>a:only-child{color:currentColor}.rp-btn-primary:hover>a:only-child:after{content:"";position:absolute;top:0;left:0;bottom:0;right:0;background:0 0}.rp-btn-primary.active,.rp-btn-primary:active{color:#f2f2f2;background-color:#2b85e4;border-color:#2b85e4}.rp-btn-primary.active>a:only-child,.rp-btn-primary:active>a:only-child{color:currentColor}.rp-btn-primary.active>a:only-child:after,.rp-btn-primary:active>a:only-child:after{content:"";position:absolute;top:0;left:0;bottom:0;right:0;background:0 0}.rp-btn-primary.disabled,.rp-btn-primary.disabled.active,.rp-btn-primary.disabled:active,.rp-btn-primary.disabled:focus,.rp-btn-primary.disabled:hover,.rp-btn-primary[disabled],.rp-btn-primary[disabled].active,.rp-btn-primary[disabled]:active,.rp-btn-primary[disabled]:focus,.rp-btn-primary[disabled]:hover,fieldset[disabled] .rp-btn-primary,fieldset[disabled] .rp-btn-primary.active,fieldset[disabled] .rp-btn-primary:active,fieldset[disabled] .rp-btn-primary:focus,fieldset[disabled] .rp-btn-primary:hover{color:#bbbec4;background-color:#f7f7f7;border-color:#dddee1}.rp-btn-primary.disabled.active>a:only-child,.rp-btn-primary.disabled:active>a:only-child,.rp-btn-primary.disabled:focus>a:only-child,.rp-btn-primary.disabled:hover>a:only-child,.rp-btn-primary.disabled>a:only-child,.rp-btn-primary[disabled].active>a:only-child,.rp-btn-primary[disabled]:active>a:only-child,.rp-btn-primary[disabled]:focus>a:only-child,.rp-btn-primary[disabled]:hover>a:only-child,.rp-btn-primary[disabled]>a:only-child,fieldset[disabled] .rp-btn-primary.active>a:only-child,fieldset[disabled] .rp-btn-primary:active>a:only-child,fieldset[disabled] .rp-btn-primary:focus>a:only-child,fieldset[disabled] .rp-btn-primary:hover>a:only-child,fieldset[disabled] .rp-btn-primary>a:only-child{color:currentColor}.rp-btn-primary.disabled.active>a:only-child:after,.rp-btn-primary.disabled:active>a:only-child:after,.rp-btn-primary.disabled:focus>a:only-child:after,.rp-btn-primary.disabled:hover>a:only-child:after,.rp-btn-primary.disabled>a:only-child:after,.rp-btn-primary[disabled].active>a:only-child:after,.rp-btn-primary[disabled]:active>a:only-child:after,.rp-btn-primary[disabled]:focus>a:only-child:after,.rp-btn-primary[disabled]:hover>a:only-child:after,.rp-btn-primary[disabled]>a:only-child:after,fieldset[disabled] .rp-btn-primary.active>a:only-child:after,fieldset[disabled] .rp-btn-primary:active>a:only-child:after,fieldset[disabled] .rp-btn-primary:focus>a:only-child:after,fieldset[disabled] .rp-btn-primary:hover>a:only-child:after,fieldset[disabled] .rp-btn-primary>a:only-child:after{content:"";position:absolute;top:0;left:0;bottom:0;right:0;background:0 0}.rp-btn-primary.active,.rp-btn-primary:active,.rp-btn-primary:hover{color:#fff}.rp-btn-primary:focus{-webkit-box-shadow:0 0 0 2px rgba(45,140,240,.2);box-shadow:0 0 0 2px rgba(45,140,240,.2)}.rp-btn-group:not(.rp-btn-group-vertical) .rp-btn-primary:not(:first-child):not(:last-child){border-right-color:#2b85e4;border-left-color:#2b85e4}.rp-btn-group:not(.rp-btn-group-vertical) .rp-btn-primary:first-child:not(:last-child){border-right-color:#2b85e4}.rp-btn-group:not(.rp-btn-group-vertical) .rp-btn-primary:first-child:not(:last-child)[disabled]{border-right-color:#dddee1}.rp-btn-group:not(.rp-btn-group-vertical) .rp-btn-primary+.rp-btn,.rp-btn-group:not(.rp-btn-group-vertical) .rp-btn-primary:last-child:not(:first-child){border-left-color:#2b85e4}.rp-btn-group:not(.rp-btn-group-vertical) .rp-btn-primary+.rp-btn[disabled],.rp-btn-group:not(.rp-btn-group-vertical) .rp-btn-primary:last-child:not(:first-child)[disabled]{border-left-color:#dddee1}.rp-btn-group-vertical .rp-btn-primary:not(:first-child):not(:last-child){border-top-color:#2b85e4;border-bottom-color:#2b85e4}.rp-btn-group-vertical .rp-btn-primary:first-child:not(:last-child){border-bottom-color:#2b85e4}.rp-btn-group-vertical .rp-btn-primary:first-child:not(:last-child)[disabled]{border-top-color:#dddee1}.rp-btn-group-vertical .rp-btn-primary+.rp-btn,.rp-btn-group-vertical .rp-btn-primary:last-child:not(:first-child){border-top-color:#2b85e4}.rp-btn-group-vertical .rp-btn-primary+.rp-btn[disabled],.rp-btn-group-vertical .rp-btn-primary:last-child:not(:first-child)[disabled]{border-bottom-color:#dddee1}#card-tips{margin-top: 5px;}.rp-btn-small {padding: 2px 7px;font-size: 12px;border-radius: 3px;';