// ==UserScript==
// @name         Telegram without Muted
// @namespace    hidemuted.telegram.aurium.one
// @version      0.3
// @description  Hide muted chats from chat list.
// @author       Aurélio A. Heckert
// @match        https://web.telegram.org/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    setInterval(function() {
        jQuery('.im_dialog_badge_muted').parents('li.im_dialog_wrap').hide();
    }, 2000);
})();