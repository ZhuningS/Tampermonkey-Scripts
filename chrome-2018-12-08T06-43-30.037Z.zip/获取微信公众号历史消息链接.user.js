// ==UserScript==
// @name         获取微信公众号历史消息链接
// @version      0.4
// @description  Get History Msg Links for WeChat
// @namespace    http://www.cnblogs.com/Chary/
// @author       CharyGao
// @match        http://mp.weixin.qq.com/s?*
// @match        https://mp.weixin.qq.com/s?*
// @match        https://mp.weixin.qq.com/s?*
// @match        http://mp.weixin.qq.com/s/*
// @match        file:///*
// @grant        GM_addStyle
// @run-at       document-end
// @require     https://cdn.bootcss.com/jquery/3.3.1/jquery.js
// @icon         https://res.wx.qq.com/zh_CN/htmledition/v2/images/favicon31e225.ico
// ==/UserScript==

GM_addStyle('span.weui_media_hd{width:100px!important;float:left!important;} ' +
    '#down_url_links{white-space:nowrap!important;background-color:orange!important;} ' +
    //'#img-content{position:fixed!important;z-index:100!important;top:20px!important;left:2%!important;height:95%!important;width:96%!important;overflow:scroll!important;}' +
    '.img_loading{margin-left: auto;margin-right: auto;display: block;} .rich_media_area_primary_inner{max-width: 90%!important;}'+
    '#js_pc_qr_code{visibility:hidden!important;}' +
    '#page-content{background-color:rgba(0,0,0,0)!important;}' +
    '#js_profile_qrcode_img{height:100px!important;width:100px!important;}'// +'img{width:auto!important;height:auto!important;display: block!important;margin-left: auto!important;margin-right: auto!important;}'
);//直接下载所有图片
(function ($) {
    'use strict';
    $(function () {
        $('img').each(function () {//直接下载所有图片
            var dataSrc = $(this).attr('data-src');
            if (dataSrc) {
                $(this).attr('src', dataSrc);
                $(this).attr('_src', dataSrc);
                $(this).removeAttr('data-src');
                $(this).removeAttr('style');
            }
        });
        if ($('#down_url')) {
            $('#down_url').remove();
        };
        $(document.body).prepend('<div id="down_url" ></div>');
        $('#down_url').append('links count: , ' + $('h4.weui_media_title').length + '<br>');

        $('#js_view_source').href = window.msg_source_url;
        $('#js_view_source').target = '_blank';

        $('h4.weui_media_title').each(function (i) {
            var link_href = $(this).attr('hrefs');
            var link_times = $(this).siblings('p.weui_media_extra_info')//.nextElementSibling.innerText
            if (link_href && link_times) {
                var down_link = '<div id="down_url_links">' + i + ' , ' + link_href + ' , ' + $(this).text() + ' , ' + link_times[0].innerText + '</div>';
                $('#down_url').append(down_link);
            }
        }

        );
    });
})(window.jQuery.noConflict(true));