"use strict";
// ==UserScript==
// @name         网页文本编辑,做笔记的好选择
// @namespace    http://tampermonkey.net/
// @version      0.17
// @description  所见即所得！
// @author       You
// @match        *
// @include      *
// @grant        none
// ==/UserScript==
(function () {
    'use strict';
    //对本地打开的网页的修改貌似无法保存......
    //获取鼠标位置
    var path;
    document.addEventListener('mouseover', function (event) {
        if (event.target instanceof HTMLElement) {
            path = nodePath(event.target);
            outline(event.target);
        }
    });
    //监测 shift+?事件
    document.addEventListener('keydown', function (event) {
        if (!event.ctrlKey)
            return false;
        switch (event.code) {
            case 'KeyQ':
                editSelect();
                break;
            case 'Backspace':
                deleteSelect();
                break;
            case 'KeyC': //c
                copyTitle(); //复制title  这里不加break是为了不影响正常的复制行为
            case "KeyW": //w
                console.log("path", path);
                break;
            default:
                return true;
        } //屏蔽浏览器对于这些快捷键的响应避免一些奇奇怪怪的操作
        event.preventDefault();
        event.returnValue = false;
        return false;
    });
    /**
     * 设置元素可编辑并获取 逐级向上获取titile
     */
    function editSelect() {
        var selectElem = path[0];
        selectElem.setAttribute("contenteditable", "true");
        copyTitle();
    }
    var div = document.createElement('div');
    div.style.display = "none";
    /**
     * 移除选中的元素 不使用remove 是因为这个方法并没有真正删除
     */
    function deleteSelect() {
        div.appendChild(path[0]);
        div.innerHTML = "";
    }
    var input = document.createElement('input');
    input.setAttribute('type', 'hidden');
    input.setAttribute('readonly', 'readonly');
    document.body.appendChild(input);
    /**
    * 设置一个影藏的文本框用来复制文本
    */
    function copyTitle() {
        //获取元素的描述并将他们添加到剪贴板  目前支持mdn 其它的可能支持
        var title;
        //这里抛弃后两个元素是因为他们不是一般的elem元素了
        for (var index = 0; index < path.length - 2; index++) {
            title = path[index].getAttribute("title");
            if (title)
                break;
        }
        input.setAttribute('value', title);
        input.select();
        document.execCommand('copy'); //复制
    }
    function outline(elemt) {
        if (elemt.style.outline == "2px solid red")
            return;
        elemt.style.outline = "2px solid red";
        setTimeout(function () {
            if (elemt == path[0]) {
                outline(elemt);
                return;
            }
            elemt.style.outline = "";
        }, 500);
    }
    /**
     * 获取一个元素的所有父节点到html为止
     */
    function nodePath(node) {
        var path = [node];
        while (node.parentElement != null) {
            node = node.parentElement;
            path.push(node);
        }
        return path;
    }
})();
